import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import {
  Estudiante,
  EstudiantesResponse,
  EstudianteResponse,
  QueryParams,
} from '../models/estudiante.model';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class EstudianteService {
  private apiUrl = `${environment.apiUrl}/api/estudiantes`;

  constructor(private http: HttpClient) {}

  // Obtener todos los estudiantes con paginación y búsqueda
  getEstudiantes(params: QueryParams = {}): Observable<EstudiantesResponse> {
    let httpParams = new HttpParams();
    if (params.page) httpParams = httpParams.set('page', params.page.toString());
    if (params.limit) httpParams = httpParams.set('limit', params.limit.toString());
    if (params.search) httpParams = httpParams.set('search', params.search);
    if (params.sortField) httpParams = httpParams.set('sortField', params.sortField);
    if (params.sortOrder) httpParams = httpParams.set('sortOrder', params.sortOrder);

    return this.http
      .get<EstudiantesResponse>(this.apiUrl, { params: httpParams })
      .pipe(catchError(this.handleError));
  }

  // Obtener estudiante por ID
  getEstudianteById(id: string): Observable<EstudianteResponse> {
    return this.http
      .get<EstudianteResponse>(`${this.apiUrl}/${id}`)
      .pipe(catchError(this.handleError));
  }

  // Crear estudiante
  createEstudiante(estudiante: Partial<Estudiante>): Observable<EstudianteResponse> {
    return this.http
      .post<EstudianteResponse>(this.apiUrl, estudiante)
      .pipe(catchError(this.handleError));
  }

  // Actualizar estudiante
  updateEstudiante(id: string, estudiante: Partial<Estudiante>): Observable<EstudianteResponse> {
    return this.http
      .put<EstudianteResponse>(`${this.apiUrl}/${id}`, estudiante)
      .pipe(catchError(this.handleError));
  }

  // Eliminar estudiante
  deleteEstudiante(id: string): Observable<EstudianteResponse> {
    return this.http
      .delete<EstudianteResponse>(`${this.apiUrl}/${id}`)
      .pipe(catchError(this.handleError));
  }

  // Manejo central de errores HTTP
  private handleError(error: any): Observable<never> {
    let errorMessage = 'Ocurrió un error inesperado';
    if (error.error?.message) {
      errorMessage = error.error.message;
    } else if (error.message) {
      errorMessage = error.message;
    }
    return throwError(() => new Error(errorMessage));
  }
}
