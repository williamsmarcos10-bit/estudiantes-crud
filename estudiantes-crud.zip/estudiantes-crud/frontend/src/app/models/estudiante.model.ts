export interface Estudiante {
  _id?: string;
  nombre: string;
  carnet: string;
  email: string;
  carrera: string;
  semestre: number;
  estado: 'Activo' | 'Inactivo';
  createdAt?: string;
  updatedAt?: string;
}

export interface PaginationInfo {
  total: number;
  page: number;
  limit: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPrevPage: boolean;
}

export interface EstudiantesResponse {
  success: boolean;
  data: Estudiante[];
  pagination: PaginationInfo;
}

export interface EstudianteResponse {
  success: boolean;
  data: Estudiante;
  message?: string;
}

export interface QueryParams {
  page?: number;
  limit?: number;
  search?: string;
  sortField?: string;
  sortOrder?: 'asc' | 'desc';
}
