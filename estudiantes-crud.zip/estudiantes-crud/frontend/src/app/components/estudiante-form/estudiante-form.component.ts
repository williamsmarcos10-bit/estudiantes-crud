import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2';

import { EstudianteService } from '../../services/estudiante.service';
import { Estudiante } from '../../models/estudiante.model';

@Component({
  selector: 'app-estudiante-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './estudiante-form.component.html',
  styleUrls: ['./estudiante-form.component.scss'],
})
export class EstudianteFormComponent implements OnInit {
  @Input() estudianteEdit: Estudiante | null = null;
  @Output() formClosed = new EventEmitter<void>();
  @Output() formSaved = new EventEmitter<void>();

  form!: FormGroup;
  isSubmitting = false;

  carreras = [
    'Ing. en Sistemas',
    'Ing. Industrial',
    'Lic. en Informática',
    'Ing. Civil',
    'Lic. en Administración',
    'Ing. Mecánica',
    'Ing. Electrónica',
    'Lic. en Contaduría',
  ];

  constructor(private fb: FormBuilder, private estudianteService: EstudianteService) {}

  ngOnInit(): void {
    this.buildForm();
    if (this.estudianteEdit) {
      this.form.patchValue(this.estudianteEdit);
    }
  }

  get isEditing(): boolean {
    return !!this.estudianteEdit?._id;
  }

  private buildForm(): void {
    this.form = this.fb.group({
      nombre: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(100)]],
      carnet: ['', [Validators.required, Validators.maxLength(20)]],
      email: ['', [Validators.required, Validators.email]],
      carrera: ['', Validators.required],
      semestre: [
        '',
        [Validators.required, Validators.min(1), Validators.max(12), Validators.pattern(/^\d+$/)],
      ],
      estado: ['Activo', Validators.required],
    });
  }

  // Helpers para mensajes de error
  hasError(field: string, error: string): boolean {
    const ctrl = this.form.get(field);
    return !!(ctrl && ctrl.touched && ctrl.hasError(error));
  }

  isInvalid(field: string): boolean {
    const ctrl = this.form.get(field);
    return !!(ctrl && ctrl.invalid && ctrl.touched);
  }

  onSubmit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.isSubmitting = true;
    const data: Partial<Estudiante> = this.form.value;

    const action$ = this.isEditing
      ? this.estudianteService.updateEstudiante(this.estudianteEdit!._id!, data)
      : this.estudianteService.createEstudiante(data);

    action$.subscribe({
      next: () => {
        Swal.fire({
          icon: 'success',
          title: this.isEditing ? 'Actualizado' : 'Creado',
          text: `Estudiante ${this.isEditing ? 'actualizado' : 'creado'} correctamente.`,
          timer: 1800,
          showConfirmButton: false,
        });
        this.isSubmitting = false;
        this.formSaved.emit();
      },
      error: (err) => {
        this.isSubmitting = false;
        Swal.fire('Error', err.message, 'error');
      },
    });
  }

  onClose(): void {
    this.formClosed.emit();
  }
}
