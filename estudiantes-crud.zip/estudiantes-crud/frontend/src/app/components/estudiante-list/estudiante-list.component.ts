import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, takeUntil } from 'rxjs/operators';
import Swal from 'sweetalert2';

import { EstudianteService } from '../../services/estudiante.service';
import { Estudiante, PaginationInfo } from '../../models/estudiante.model';
import { EstudianteFormComponent } from '../estudiante-form/estudiante-form.component';

@Component({
  selector: 'app-estudiante-list',
  standalone: true,
  imports: [CommonModule, FormsModule, EstudianteFormComponent],
  templateUrl: './estudiante-list.component.html',
  styleUrls: ['./estudiante-list.component.scss'],
})
export class EstudianteListComponent implements OnInit, OnDestroy {
  estudiantes: Estudiante[] = [];
  pagination: PaginationInfo = {
    total: 0,
    page: 1,
    limit: 5,
    totalPages: 0,
    hasNextPage: false,
    hasPrevPage: false,
  };

  searchTerm = '';
  isLoading = false;
  showForm = false;
  selectedEstudiante: Estudiante | null = null;

  sortField = 'createdAt';
  sortOrder: 'asc' | 'desc' = 'desc';

  limitOptions = [5, 10, 20];
  pages: number[] = [];

  private searchSubject = new Subject<string>();
  private destroy$ = new Subject<void>();

  constructor(private estudianteService: EstudianteService) {}

  ngOnInit(): void {
    this.loadEstudiantes();

    // Búsqueda dinámica con debounce (500ms)
    this.searchSubject
      .pipe(debounceTime(500), distinctUntilChanged(), takeUntil(this.destroy$))
      .subscribe(() => {
        this.pagination.page = 1;
        this.loadEstudiantes();
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadEstudiantes(): void {
    this.isLoading = true;
    this.estudianteService
      .getEstudiantes({
        page: this.pagination.page,
        limit: this.pagination.limit,
        search: this.searchTerm,
        sortField: this.sortField,
        sortOrder: this.sortOrder,
      })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (res) => {
          this.estudiantes = res.data;
          this.pagination = res.pagination;
          this.buildPageArray();
          this.isLoading = false;
        },
        error: (err) => {
          this.isLoading = false;
          Swal.fire('Error', err.message, 'error');
        },
      });
  }

  onSearchChange(): void {
    this.searchSubject.next(this.searchTerm);
  }

  onLimitChange(): void {
    this.pagination.page = 1;
    this.loadEstudiantes();
  }

  goToPage(page: number): void {
    if (page < 1 || page > this.pagination.totalPages) return;
    this.pagination.page = page;
    this.loadEstudiantes();
  }

  sortBy(field: string): void {
    if (this.sortField === field) {
      this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortField = field;
      this.sortOrder = 'asc';
    }
    this.loadEstudiantes();
  }

  getSortIcon(field: string): string {
    if (this.sortField !== field) return '↕';
    return this.sortOrder === 'asc' ? '↑' : '↓';
  }

  openCreateForm(): void {
    this.selectedEstudiante = null;
    this.showForm = true;
  }

  openEditForm(estudiante: Estudiante): void {
    this.selectedEstudiante = { ...estudiante };
    this.showForm = true;
  }

  closeForm(): void {
    this.showForm = false;
    this.selectedEstudiante = null;
  }

  onFormSaved(): void {
    this.closeForm();
    this.loadEstudiantes();
  }

  confirmDelete(estudiante: Estudiante): void {
    Swal.fire({
      title: '¿Eliminar estudiante?',
      html: `Se eliminará a <strong>${estudiante.nombre}</strong> permanentemente.`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#6c757d',
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
    }).then((result) => {
      if (result.isConfirmed) {
        this.deleteEstudiante(estudiante._id!);
      }
    });
  }

  private deleteEstudiante(id: string): void {
    this.estudianteService.deleteEstudiante(id).subscribe({
      next: () => {
        Swal.fire({
          icon: 'success',
          title: 'Eliminado',
          text: 'Estudiante eliminado correctamente.',
          timer: 1800,
          showConfirmButton: false,
        });
        // Si era el último de la página, retroceder
        if (this.estudiantes.length === 1 && this.pagination.page > 1) {
          this.pagination.page--;
        }
        this.loadEstudiantes();
      },
      error: (err) => Swal.fire('Error', err.message, 'error'),
    });
  }

  private buildPageArray(): void {
    const total = this.pagination.totalPages;
    const current = this.pagination.page;
    const delta = 2;
    const pages: number[] = [];

    for (let i = Math.max(1, current - delta); i <= Math.min(total, current + delta); i++) {
      pages.push(i);
    }
    this.pages = pages;
  }

  getStartRecord(): number {
    return (this.pagination.page - 1) * this.pagination.limit + 1;
  }

  getEndRecord(): number {
    return Math.min(this.pagination.page * this.pagination.limit, this.pagination.total);
  }
}
