const Estudiante = require('../models/estudiante.model');

// GET /api/estudiantes — Obtener todos con paginación y búsqueda
const getEstudiantes = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 5;
    const search = req.query.search?.trim() || '';
    const sortField = req.query.sortField || 'createdAt';
    const sortOrder = req.query.sortOrder === 'asc' ? 1 : -1;

    const skip = (page - 1) * limit;

    // Filtro de búsqueda por nombre, carné o email
    let filter = {};
    if (search) {
      filter = {
        $or: [
          { nombre: { $regex: search, $options: 'i' } },
          { carnet: { $regex: search, $options: 'i' } },
          { email: { $regex: search, $options: 'i' } },
        ],
      };
    }

    const sort = { [sortField]: sortOrder };

    const [estudiantes, total] = await Promise.all([
      Estudiante.find(filter).sort(sort).skip(skip).limit(limit),
      Estudiante.countDocuments(filter),
    ]);

    const totalPages = Math.ceil(total / limit);

    res.status(200).json({
      success: true,
      data: estudiantes,
      pagination: {
        total,
        page,
        limit,
        totalPages,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al obtener estudiantes', error: error.message });
  }
};

// GET /api/estudiantes/:id — Obtener un estudiante por ID
const getEstudianteById = async (req, res) => {
  try {
    const estudiante = await Estudiante.findById(req.params.id);
    if (!estudiante) {
      return res.status(404).json({ success: false, message: 'Estudiante no encontrado' });
    }
    res.status(200).json({ success: true, data: estudiante });
  } catch (error) {
    if (error.name === 'CastError') {
      return res.status(400).json({ success: false, message: 'ID inválido' });
    }
    res.status(500).json({ success: false, message: 'Error al obtener el estudiante', error: error.message });
  }
};

// POST /api/estudiantes — Crear un nuevo estudiante
const createEstudiante = async (req, res) => {
  try {
    const { nombre, carnet, email, carrera, semestre, estado } = req.body;

    // Verificar duplicados
    const existingCarnet = await Estudiante.findOne({ carnet });
    if (existingCarnet) {
      return res.status(409).json({ success: false, message: 'El carné ya está registrado' });
    }

    const existingEmail = await Estudiante.findOne({ email: email?.toLowerCase() });
    if (existingEmail) {
      return res.status(409).json({ success: false, message: 'El email ya está registrado' });
    }

    const nuevoEstudiante = new Estudiante({ nombre, carnet, email, carrera, semestre, estado });
    const saved = await nuevoEstudiante.save();

    res.status(201).json({ success: true, message: 'Estudiante creado exitosamente', data: saved });
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(e => e.message);
      return res.status(400).json({ success: false, message: messages.join(', ') });
    }
    res.status(500).json({ success: false, message: 'Error al crear el estudiante', error: error.message });
  }
};

// PUT /api/estudiantes/:id — Actualizar un estudiante
const updateEstudiante = async (req, res) => {
  try {
    const { nombre, carnet, email, carrera, semestre, estado } = req.body;

    // Verificar duplicados (excluyendo el registro actual)
    if (carnet) {
      const existingCarnet = await Estudiante.findOne({ carnet, _id: { $ne: req.params.id } });
      if (existingCarnet) {
        return res.status(409).json({ success: false, message: 'El carné ya está registrado por otro estudiante' });
      }
    }

    if (email) {
      const existingEmail = await Estudiante.findOne({ email: email.toLowerCase(), _id: { $ne: req.params.id } });
      if (existingEmail) {
        return res.status(409).json({ success: false, message: 'El email ya está registrado por otro estudiante' });
      }
    }

    const updated = await Estudiante.findByIdAndUpdate(
      req.params.id,
      { nombre, carnet, email, carrera, semestre, estado },
      { new: true, runValidators: true }
    );

    if (!updated) {
      return res.status(404).json({ success: false, message: 'Estudiante no encontrado' });
    }

    res.status(200).json({ success: true, message: 'Estudiante actualizado exitosamente', data: updated });
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(e => e.message);
      return res.status(400).json({ success: false, message: messages.join(', ') });
    }
    if (error.name === 'CastError') {
      return res.status(400).json({ success: false, message: 'ID inválido' });
    }
    res.status(500).json({ success: false, message: 'Error al actualizar el estudiante', error: error.message });
  }
};

// DELETE /api/estudiantes/:id — Eliminar un estudiante
const deleteEstudiante = async (req, res) => {
  try {
    const deleted = await Estudiante.findByIdAndDelete(req.params.id);
    if (!deleted) {
      return res.status(404).json({ success: false, message: 'Estudiante no encontrado' });
    }
    res.status(200).json({ success: true, message: 'Estudiante eliminado exitosamente', data: deleted });
  } catch (error) {
    if (error.name === 'CastError') {
      return res.status(400).json({ success: false, message: 'ID inválido' });
    }
    res.status(500).json({ success: false, message: 'Error al eliminar el estudiante', error: error.message });
  }
};

module.exports = {
  getEstudiantes,
  getEstudianteById,
  createEstudiante,
  updateEstudiante,
  deleteEstudiante,
};
