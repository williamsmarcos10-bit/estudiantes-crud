const mongoose = require('mongoose');

const estudianteSchema = new mongoose.Schema(
  {
    nombre: {
      type: String,
      required: [true, 'El nombre es requerido'],
      minlength: [3, 'El nombre debe tener al menos 3 caracteres'],
      trim: true,
    },
    carnet: {
      type: String,
      required: [true, 'El carné es requerido'],
      unique: true,
      trim: true,
    },
    email: {
      type: String,
      required: [true, 'El email es requerido'],
      unique: true,
      lowercase: true,
      trim: true,
      match: [/^\S+@\S+\.\S+$/, 'Formato de email inválido'],
    },
    carrera: {
      type: String,
      required: [true, 'La carrera es requerida'],
      trim: true,
    },
    semestre: {
      type: Number,
      required: [true, 'El semestre es requerido'],
      min: [1, 'El semestre mínimo es 1'],
      max: [12, 'El semestre máximo es 12'],
    },
    estado: {
      type: String,
      enum: ['Activo', 'Inactivo'],
      default: 'Activo',
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

// Índice de texto para búsqueda eficiente
estudianteSchema.index({ nombre: 'text', carnet: 'text', email: 'text' });

const Estudiante = mongoose.model('Estudiante', estudianteSchema);

module.exports = Estudiante;
