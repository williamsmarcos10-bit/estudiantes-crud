const express = require('express');
const router = express.Router();
const {
  getEstudiantes,
  getEstudianteById,
  createEstudiante,
  updateEstudiante,
  deleteEstudiante,
} = require('../controllers/estudiante.controller');

// GET    /api/estudiantes          → Listar con paginación y búsqueda
// POST   /api/estudiantes          → Crear estudiante
router.route('/').get(getEstudiantes).post(createEstudiante);

// GET    /api/estudiantes/:id      → Obtener por ID
// PUT    /api/estudiantes/:id      → Actualizar
// DELETE /api/estudiantes/:id      → Eliminar
router.route('/:id').get(getEstudianteById).put(updateEstudiante).delete(deleteEstudiante);

module.exports = router;
